import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  customers: any = [
    {
      name: 'Mahi',
      productName: 'Seven-7 COT TEE',
      price: 1499,
      purchasedDate: '07/07/2020'
    },
    {
      name: 'Suresh Raina',
      productName: 'Seven-CAMO UPPER',
      price: 2499,
      purchasedDate: '16/08/2020'
    },
    {
      name: 'Ravindra Jadeja',
      productName: 'Seven-CSK MATCH TEE YELLOW (2020)',
      price: 1199,
      purchasedDate: '12/09/2020'
    },
    {
      name: 'Bravo',
      productName: 'Seven-CUSTOM MOTORS TEE',
      price: 799,
      purchasedDate: '03/05/2020'
    },
    {
      name: 'Shardul',
      productName: 'Seven-CAMO UPPER',
      price: 2499,
      purchasedDate: '08/10/2020'
    },
    {
      name: 'Shane Watson',
      productName: 'Seven-CSK MATCH TEE YELLOW (2020)',
      price: 1199,
      purchasedDate: '15/11/2020'
    },
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
