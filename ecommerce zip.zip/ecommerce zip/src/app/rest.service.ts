import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RestService {

  constructor(private httpClient: HttpClient) { }
  register(data: any) {
    const options = {
      headers: new HttpHeaders().set('Content-Type', 'application/json').set('authorization', '3434535')
    };
     return this.httpClient.post(`${environment.apiUrl}user/register`, data, options);
  }

}
