import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { ProductsComponent } from './products/products.component';
import { CustomersComponent } from './customers/customers.component';
import { CartComponent } from './cart/cart.component';
import { EmployeesComponent } from './employees/employees.component';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { SelectedProductComponent } from './selected-product/selected-product.component';
import { ProductDescriptionComponent } from './selected-product/product-description/product-description.component';
import { SpecificationsComponent } from './selected-product/specifications/specifications.component';
import { RatingsReviewsComponent } from './selected-product/ratings-reviews/ratings-reviews.component';



const routes: Routes = [
  {path: '', redirectTo:'homepage', pathMatch:'full'},
  {path: 'homepage', component: HomepageComponent},
  {path: 'products', component: ProductsComponent},
  {path: 'products/:brand', component: ProductsComponent},
  {path: 'products/:accessory', component: ProductsComponent},
  {path: 'customers', component: CustomersComponent},
  {path: 'cart', component: CartComponent},
  {path: 'employees', component: EmployeesComponent},
  {path: 'selectedProduct', component: SelectedProductComponent, children: [
    {path: 'product-description', component: ProductDescriptionComponent},
    {path: 'specifications', component: SpecificationsComponent},
    {path: 'ratings-reviews', component: RatingsReviewsComponent}
  ]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
