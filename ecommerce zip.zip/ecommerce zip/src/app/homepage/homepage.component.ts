import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  isShowOrHide = true;
  products: any = [];

  constructor() { }

  ngOnInit(): void {
    this.products = [
      {
        name: 'CSK Match Tee',
        discount: 'Upto 10% off',
        models: 'Tees & more',
        imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Back.jpg'
      },
      {
        name: 'Seven-ATLAS Tee navy blue',
        discount: 'Upto 50% off',
        models: 'Tees & more',
        imgSrc: 'https://www.7.life/sf/wp-content/uploads/2019/09/SAMT19-101-1-2-247x300.jpg'
      },
      {
        name: 'Seven-ATLAS Tee blue',
        discount: 'Upto 30% off',
        models: 'Tees & more',
        imgSrc: 'https://www.7.life/sf/wp-content/uploads/2019/09/SAMT19-101-2-2-247x300.jpg'
      },
      {
        name: 'Seven-ATLAS Tee orange',
        discount: 'Upto 70% off',
        models: 'Tees & more',
        imgSrc: 'https://www.7.life/sf/wp-content/uploads/2019/09/SAMT19-101-5-2-247x300.jpg'
      }
    ]
  }

  showOrHide() {
      this.isShowOrHide = !this.isShowOrHide;
  }
}
