import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ValidationErrors, ValidatorFn, AbstractControl } from '@angular/forms';
import { RestService } from '../../rest.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  registerForm!: FormGroup;
  
  constructor(private formBuilder: FormBuilder, private restService: RestService) { 
    ;
  }

  ngOnInit(): void {
    this.createRegisterForm();
    this.registerForm.setValue(
      {user: {firstName: 'admin', lastName: '123'}, phoneNumber: 9845252094, userName: 'abdefg@gmail.com', password: 'avsdwe123'}); 
  }

  createRegisterForm(){
    this.registerForm = this.formBuilder.group({
       user: this.formBuilder.group({
        firstName: ['', [Validators.required]],
        lastName: ['',[Validators.required]],
       }),
       phoneNumber: ['',[Validators.required, Validators.minLength(10)]],
       userName: ['', [Validators.required, Validators.email, Validators.pattern('^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$')]],
       password: ['', [Validators.required]]
    })
  }

  register() {
    console.log(this.registerForm.value);
    this.registerForm.reset(); 
    this.restService.register(this.registerForm.value).subscribe( (response) => {
      console.log(response);
    }, (error) => {
      
    });
  }

  fieldNameStatus(fieldName: string | number) {
    if(this.registerForm.controls[fieldName].touched && this.registerForm.controls[fieldName].errors?.required) {
      return true;
    }
    else{
      return false;
    }
  }

}
