import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {


  employees:any =[
    {
      id: 1111,
      name: 'Vishva',
      location: 'Hyderabad'
    },
    {
      id: 1112,
      name: 'Bummy',
      location: 'warangal'
    },
    {
      id: 1113,
      name: 'Manoj',
      location: 'Banglore'
    },
    {
      id: 1114,
      name: 'Rohit',
      location: 'Mumbai'
    }
  ];
  selectedEmployee: any;
  constructor() { }

  ngOnInit(): void {
  }
  
  getEmployee(data: any) {
    console.log(data);
    this.selectedEmployee = data;
  }


}
