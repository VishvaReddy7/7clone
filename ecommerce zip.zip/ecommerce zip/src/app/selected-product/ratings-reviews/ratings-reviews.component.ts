import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ratings-reviews',
  templateUrl: './ratings-reviews.component.html',
  styleUrls: ['./ratings-reviews.component.css']
})
export class RatingsReviewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
