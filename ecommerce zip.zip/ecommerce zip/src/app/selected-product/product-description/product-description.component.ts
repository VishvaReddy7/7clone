import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/common.service';


@Component({
  selector: 'app-product-description',
  templateUrl: './product-description.component.html',
  styleUrls: ['./product-description.component.css']
})
export class ProductDescriptionComponent implements OnInit {
  selectedProduct: any;
  productDescription: any;
  constructor(private commonService: CommonService) { }

  ngOnInit(): void {
    this.selectedProduct = this.commonService.getSelectedProduct();
    if(this.selectedProduct && this.selectedProduct.productDescription) {
      this.productDescription = this.selectedProduct.productDescription;
      console.log(this.productDescription);
    }
  }

}
