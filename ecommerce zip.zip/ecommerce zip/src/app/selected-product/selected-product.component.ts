import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-selected-product',
  templateUrl: './selected-product.component.html',
  styleUrls: ['./selected-product.component.css']
})
export class SelectedProductComponent implements OnInit {
  selectedProduct: any = {};
  filteredProducts: any = [];
  cartProducts: any = [];
  constructor(private commonService: CommonService, private router: Router) { }

  ngOnInit(): void {

    this.selectedProduct = this.commonService.getSelectedProduct();
    if(!this.selectedProduct) {
      this.router.navigate(['products']);
    }
  }

  addToCart(selectedProduct: any) {
    let isExist = false;
     this.cartProducts.forEach((product: any) => {
        if(product.id === this.selectedProduct.id){
          isExist = true;
        }
      })
      if(!isExist){
        this.cartProducts.push(this.selectedProduct);
        window.alert("Added to cart");
        this.filteredProducts.forEach((product: any) => {
          if(product.id === selectedProduct.id){
            product.inCart = true;
          }
        })
      }
      else{
        window.alert("Product already added to the cart");
      }
      // this.commonService.cartData = this.cartProducts; 
         this.commonService.setCartData(this.cartProducts);
  }

}
