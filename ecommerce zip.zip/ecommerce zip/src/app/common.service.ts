import { Injectable } from '@angular/core';

@Injectable()
export class CommonService {
  
  cartProducts = [];
  selectedProduct: any ={};
  products: any = [
    { 
      id: 1001,
      name:'Seven-7 COT TEE',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2019/06/5223116W8-1-510x600.jpg',
      price: 1499,
      type: 'Round Neck Tee',
      inStock: true,
      inCart: false,
      specifications: [' 60% Cotton 25% Polyetser | 5 % Viscose | 7 Cot tee','White Melange','Round Neck Tee','L, M, S, XL, XXL','Casual Wear/Regular fit','Gentle Wash'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    { 
      id: 1002,
      name:'Seven-CUSTOM MOTORS TEE',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2017/05/AM065-3-1-510x600.jpg',
      price: 799,
      type: 'Round Neck Tee',
      inStock: true,
      inCart: false,
      specifications: [' 100% cotton single jersey t shirt with screen print graphic-180 GSM','ENGLISH MANOR','Round Neck Tee','L, M, S, XL, XXL','Casual Wear/Regular fit','Gentle Wash'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1003,
      name:'Seven-CAMO UPPER',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2019/07/SAMU19-118-2-1-510x600.jpg',
      price: 2499,
      type: 'Jacket',
      inStock: false,
      inCart: false,
      specifications: [' It is a 92% Polyester and 8 % of Spandex, with Ultrasoft body touch','GREEN CAMO','Jacket','L, M, S, XL, XXL','Casual Wear/Regular fit','Gentle Wash'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1004,
      name:'Seven-CSK MATCH TEE YELLOW (2020)',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/09/1-7.jpg',
      price: 1199,
      type: 'Polo',
      inStock: true,
      inCart: false,
      specifications: [' 100% Polyester','YELLOW','Polo','L, M, S, XL, XXL','Casual Wear/Regular fit','Gentle Wash'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1005,
      name:'Seven-7 COT TEE',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2019/06/5223116W8-1-510x600.jpg',
      price: 1499,
      type: 'Round Neck Tee',
      inStock: false,
      inCart: false,
      specifications: [' 60% Cotton 25% Polyetser | 5 % Viscose | 7 Cot tee','White Melange','Round Neck Tee','L, M, S, XL, XXL','Casual Wear/Regular fit','Gentle Wash'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1006,
      name:'Seven-CUSTOM MOTORS TEE',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2017/05/AM065-3-1-510x600.jpg',
      price: 799,
      inStock: true,
      inCart: false,
      type: 'Round Neck Tee',
      specifications: [' 100% cotton single jersey t shirt with screen print graphic-180 GSM','ENGLISH MANOR','Round Neck Tee','L, M, S, XL, XXL','Casual Wear/Regular fit','Gentle Wash'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1007,
      name:'Seven-CAMO UPPER',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2019/07/SAMU19-118-2-1-510x600.jpg',
      price: 2499,
      type: 'Jacket',
      inStock: true,
      inCart: false,
      specifications: [' It is a 92% Polyester and 8 % of Spandex, with Ultrasoft body touch','GREEN CAMO','Jacket','L, M, S, XL, XXL','Casual Wear/Regular fit','Gentle Wash'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1008,
      name:'Seven-CSK MATCH TEE YELLOW (2020)',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/09/1-7.jpg',
      price: 1199,
      type: 'Polo',
      inStock: false,
      inCart: false,
      specifications: [' 100% Polyester','YELLOW','Polo','L, M, S, XL, XXL','Casual Wear/Regular fit','Gentle Wash'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1009,
      name:'CSK BAGPACK',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/10/1-1-1.jpg',
      price: 999,
      type: 'Backpack',
      inStock: true,
      inCart: false,
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1010,
      name:'MATCH CAP',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/10/19-09-2020-Myntra-Bay-315147-1.jpg',
      price: 499,
      type: 'Cap',
      inStock: true,
      inCart: false,
      specifications: ['Available in bright, solid Yellow color CSK Match Cap that are suitable for men and women, you’re sure to find the right one for you'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1011,
      name:'Seven-BATTING GLOVES-HOOK ADULT',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/02/GLV-112-L-2-247x300.jpg',
      price: 3799,
      type: 'Gloves',
      inStock: true,
      inCart: false,
      specifications: ['MEN', 'PU + LEATHER', 'Cricket'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1012,
      name:'Seven-BATTING THIGH GUARD-CLUB YOUTH',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/02/THP-1002-CR-YOUTH-2-247x300.jpg',
      price: 899,
      type: 'Thigh Guard',
      inStock: false,
      inCart: false,
      specifications: ['MEN', 'PU + LEATHER', 'Cricket'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1013,
      name:'Seven-ENGLISH WILLOW BAT BOLD',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/02/EW-106-2020-2-247x300.jpg',
      price: 13999,
      type: 'Bat',
      inStock: false,
      inCart: false,
      specifications: ['Full', 'Wood', 'Cricket'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1014,
      name:'Seven-ENGLISH WILLOW BAT DRIVE',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/02/EW-107-2020-2-247x300.jpg',
      price: 21999,
      type: 'Bat',
      inStock: true,
      inCart: false,
      specifications: ['Full', 'Wood', 'Cricket'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1015,
      name:'Seven-ENGLISH WILLOW BAT STRIKER',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/02/EW-105-2020-2-247x300.jpg',
      price: 11999,
      type: 'Bat',
      inStock: true,
      inCart: false,
      specifications: ['Full', 'Wood', 'Cricket'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1016,
      name:'CSK BAGPACK',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/10/1-1-1.jpg',
      price: 999,
      type: 'Backpack',
      inStock: false,
      inCart: false,
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1017,
      name:'MATCH CAP',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/10/19-09-2020-Myntra-Bay-315147-1.jpg',
      price: 499,
      type: 'Cap',
      inStock: false,
      inCart: false,
      specifications: ['Available in bright, solid Yellow color CSK Match Cap that are suitable for men and women, you’re sure to find the right one for you'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1018,
      name:'Seven-BATTING GLOVES-HOOK ADULT',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/02/GLV-112-L-2-247x300.jpg',
      price: 3799,
      type: 'Gloves',
      inStock: false,
      inCart: false,
      specifications: ['MEN', 'PU + LEATHER', 'Cricket'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1019,
      name:'Seven-BATTING THIGH GUARD-CLUB YOUTH',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/02/THP-1002-CR-YOUTH-2-247x300.jpg',
      price: 899,
      type: 'Thigh Guard',
      inStock: true,
      inCart: false,
      specifications: ['MEN', 'PU + LEATHER', 'Cricket'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1020,
      name:'Seven-ENGLISH WILLOW BAT BOLD',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/02/EW-106-2020-2-247x300.jpg',
      price: 13999,
      type: 'Bat',
      inStock: false,
      inCart: false,
      specifications: ['Full', 'Wood', 'Cricket'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1021,
      name:'Seven-ENGLISH WILLOW BAT DRIVE',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/02/EW-107-2020-2-247x300.jpg',
      price: 21999,
      type: 'Bat',
      inStock: false,
      inCart: false,
      specifications: ['Full', 'Wood', 'Cricket'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    },
    {
      id: 1022,
      name:'Seven-ENGLISH WILLOW BAT STRIKER',
      imgSrc:'https://www.7.life/sf/wp-content/uploads/2020/02/EW-105-2020-2-247x300.jpg',
      price: 11999,
      type: 'Bat',
      inStock: true,
      inCart: false,
      specifications: ['Full', 'Wood', 'Cricket'],
      productDescription: [
        {
          header: 'Front View',
          imgSrc: 'https://www.7.life/sf/wp-content/uploads/2021/03/Jersey-Option-Front-Front.png',
          description: 'This is an IPL 2021 jersey edition for CSK team. The kids take the feel of being the part of the team of CSK  by choosing it.'
        }
      ],
      completeSpecifications: {
        general: {
          WEIGHT: 'N/A',
          SIZE: '10, 12, 14, 8',
          CARE_INSTRUCTIONS: 'Machine Wash',
          COLOR: 'yellow'
        },
        additional: {
          FABRIC: '100% POLTYESTER',
          WARRANTY_PERIOD: '15 Days'
        }
      },
      ratingReviews: [
        {
          rating: 4,
          review: 'Excellent'
        },
        {
          rating: 5,
          review: 'Marvellous. Perfect Product'
        },
        {
          rating: 5,
          review: 'I am loving it'
        }
      ]
    } 
  ]
  // constructor() { }

  // set cartData(data){
  //   this.cartProducts = data;
  // }
  // get cartData() {
  //   return this.cartProducts;
  // }
  setCartData(data: any) {
    this.cartProducts = data;
  } 
  getCartData(){
    return this.cartProducts;
  }

 setSelectedProduct(data: any){
   return this.selectedProduct = data;
 }
 getSelectedProduct() {
   return this.selectedProduct;
 }

}
