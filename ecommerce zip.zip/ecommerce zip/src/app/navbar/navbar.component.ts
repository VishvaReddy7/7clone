import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  brands: any = ['Round Neck Tee', 'Polo', 'Jacket', 'V Neck', 'Henley'];
  accessories: any = [ 'Backpack', 'Cap', 'Gloves', 'Thigh Guard', 'Bat'];

  constructor(private router: Router) {
     
   }

  ngOnInit(): void {
    
  }
  getSelectedBrand(brand: any) {
    this.router.navigate([`/products/${brand}`]); 
  }  

  getSelectedAccessory(accessory: any){
    this.router.navigate([`/products/${accessory}`]);
  }
}
