import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartProducts: any = [];

  constructor(private commonService: CommonService ) {}

  ngOnInit(): void {
    this.cartProducts=this.commonService.getCartData();
  }
  
  remove(product: any, i: any){
      this.cartProducts.splice(i, 1);
  }

  getColor(productName: any) {
    if(productName === 'Seven-CSK MATCH TEE YELLOW (2020)') {
      return '#d26e4b';
    }
    return false;
  }

  getBorder(productName: any) {
    if(productName === 'Seven-CSK MATCH TEE YELLOW (2020)') {
      return '1px solid #d26e4b';
    }
    else {
      return '1px solid black'
    }
  }

}
