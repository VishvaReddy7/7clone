import { Component, Input, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  @Input() id: any;
  @Input() name: any;
  @Input() location: any;
  @Output() sendEmployee: any = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }

  selectEmployeeCTA(id: any, name: any, location: any){
    console.log(id, name, location);
    this.sendEmployee.emit({id, name, location});
  }

}
