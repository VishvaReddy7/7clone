import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AuthModule } from './auth/auth.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { HomepageComponent } from './homepage/homepage.component';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ProductsComponent } from './products/products.component';
import { CustomersComponent } from './customers/customers.component';
import { CartComponent } from './cart/cart.component';

import { CommonService } from './common.service';
import { EmployeesComponent } from './employees/employees.component';
import { EmployeeComponent } from './employee/employee.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SelectedProductComponent } from './selected-product/selected-product.component';
import { ProductDescriptionComponent } from './selected-product/product-description/product-description.component';
import { SpecificationsComponent } from './selected-product/specifications/specifications.component';
import { RatingsReviewsComponent } from './selected-product/ratings-reviews/ratings-reviews.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    HomepageComponent,
    ProductsComponent,
    CustomersComponent,
    CartComponent,
    EmployeesComponent,
    EmployeeComponent,
    SelectedProductComponent,
    ProductDescriptionComponent,
    SpecificationsComponent,
    RatingsReviewsComponent
  ],
  imports: [
    AuthModule,
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [CommonService],
  bootstrap: [AppComponent]
})
export class AppModule { }
