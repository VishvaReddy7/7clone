import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: any = this.commonService.products;
selectedBrand: any;

filteredProducts: any = [];
cartProducts: any = [];
  constructor(private activatedRoute: ActivatedRoute, private commonService: CommonService, private router: Router) { }

  ngOnInit(): void {
      this.activatedRoute.paramMap.subscribe( (data: any) => {
      this.selectedBrand = data.params.brand;
      if(data.params.brand){
        this.filteredProducts = this.filteredProducts = this.products.filter( (product: { type: any }) => product.type.includes(this.selectedBrand));
      }
      else{
        this.filteredProducts = this.products;
      }
      });
  }
  
  getColor(productName: any) {
    if(productName === 'Seven-CSK MATCH TEE YELLOW (2020)') {
      return '#d26e4b';
    }
    return false;
  }

  getBorder(productName: any) {
    if(productName === 'Seven-CSK MATCH TEE YELLOW (2020)') {
      return '1px solid #d26e4b';
    }
    else {
      return '1px solid black'
    }
  }

  redirectToSelectedProduct(product: any) {
    this.commonService.setSelectedProduct(product);
    this.router.navigate(['selectedProduct']);
    
  }

  addToCart(cartProduct: any, index: any) {
    let isExist = false;
     this.cartProducts.forEach((product: any) => {
        if(product.id === cartProduct.id){
          isExist = true;
        }
      })
      if(!isExist){
        this.cartProducts.push(cartProduct);
        window.alert("Added to cart");
        this.filteredProducts.forEach((product: any) => {
          if(product.id === cartProduct.id){
            product.inCart = true;
          }
        })
      }
      else{
        window.alert("Product already added to the cart");
      }
      // this.commonService.cartData = this.cartProducts; 
         this.commonService.setCartData(this.cartProducts);
  }
}



